Board:	chipKIT WF32
Digilent part number:	200-273
Rev:	B.0
03/26/2013

The following files are included in this "chipKIT WF32" project zip file:

chipKIT WF32.plc - top silk screen layer
chipKIT WF32.crc - component (top) side solder paste pattern
chipKIT WF32.stc - component (top) side solder mask pattern
chipKIT WF32.cmp - component (top side) foil pattern
chipKIT WF32.gnd - GND plane foil pattern
chipKIT WF32.pwr - internal signal foil pattern
chipKIT WF32.sol - solder (bottom side) foil pattern
chipKIT WF32.sts - solder (bottom) side solder mask pattern
chipKIT WF32.crs - solder (bottom) side solder paste pattern
chipKIT WF32.pls - bottom silk screen layer
chipKIT WF32.drl - drill tool file (drill sizes)
chipKIT WF32.drd - excellon format drill file
chipKIT WF32.dck - gerber format drill file with board dimensions
chipKIT WF32.dri - drill report file
chipKIT WF32.dim - gerber format mechanical drawing with board dimensions
chipKIT WF32.mnc - Component (top) side SMD placement coordinates
chipKIT WF32.mns - Solder (bottom) side SMD placement coordinates


All layers are plotted as viewed from the component (top) side of
the board.

The board requires 3 slot drills of 0.026" by 0.125" (all 3 26mil drills
specified in the drill file are for the slots). The slots should be
plated through holes, with a raw (unfinished) hole size of 0.026" x 0.125".
We included the three 26mil drills in the drill file, centered at the slot
center. We have included markings in the Gerber drill file to indicate
the center and final dimensions of the slots.

The board specs are:

1. Fabricate to IPC standards
2. Finished PCB thickness should be .062 +/- .005
3. Solder mask: LPI, both sides, red.
4. Silkscreen: top, white.
5. 1 oz copper.
6. Plated drills should be within 6mil of orginal drill size.

DRILL/HOLE INFORMATION


 Code  Size       		Plated		used

 T01   0.0090inch   		Y		313
 T02   0.0240inch     		Y		2
 T03   0.0260inch     		Y		3		0.026" by 0.125" slot drills	
 T04   0.0320inch		Y		3
 T05   0.0420inch   		Y		130
 T06   0.1000inch     		Y		2
 T07   0.1260inch     		N		4

Total number of drills: 457




Contact:

Mike Higgins
Digilent, Inc.
215 East Main, Suite D
Pullman, WA 99163

(509) 334-6306
Mike@digilentinc.com


